const LIST_PRODUCTS = [{
  image: "/static/products/airpod-2.png",
  name: "Light Airpod",
  producer: "Apple",
  category: "Air Pod",
  id: "P10001",
  cost: 432,
  price: 450,
  extra: 20,
  priority: 1
}, {
  image: "/static/products/airpod-3.png",
  name: "Air Pods 2",
  producer: "Apple",
  category: "Air Pod",
  id: "P10002",
  cost: 432,
  price: 450,
  extra: 20,
  priority: 1
}, {
  image: "/static/products/shoe-2.png",
  name: "Nike Shoe",
  producer: "Nike",
  category: "Shoe",
  id: "P10003",
  cost: 432,
  price: 450,
  extra: 20,
  priority: 1
}, {
  image: "/static/products/airpod-2.png",
  name: "Light Airpod",
  producer: "Apple",
  category: "Air Pod",
  id: "P10001",
  cost: 432,
  price: 450,
  extra: 20,
  priority: 1
}, {
  image: "/static/products/airpod-3.png",
  name: "Air Pods 2",
  producer: "Apple",
  category: "Air Pod",
  id: "P10002",
  cost: 432,
  price: 450,
  extra: 20,
  priority: 1
}, {
  image: "/static/products/shoe-2.png",
  name: "Nike Shoe",
  producer: "Nike",
  category: "Shoe",
  id: "P10003",
  cost: 432,
  price: 450,
  extra: 20,
  priority: 1
}, {
  image: "/static/products/airpod-2.png",
  name: "Light Airpod",
  producer: "Apple",
  category: "Air Pod",
  id: "P10001",
  cost: 432,
  price: 450,
  extra: 20,
  priority: 1
}, {
  image: "/static/products/airpod-3.png",
  name: "Air Pods 2",
  producer: "Apple",
  category: "Air Pod",
  id: "P10002",
  cost: 432,
  price: 450,
  extra: 20,
  priority: 1
}, {
  image: "/static/products/shoe-2.png",
  name: "Nike Shoe",
  producer: "Nike",
  category: "Shoe",
  id: "P10003",
  cost: 432,
  price: 450,
  extra: 20,
  priority: 1
}];
export default LIST_PRODUCTS;