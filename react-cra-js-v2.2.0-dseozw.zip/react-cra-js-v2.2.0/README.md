# UKO - Client & Admin Dashboard

## Version 1.1.0 - 29 March 2023

- Update All Dependencies
